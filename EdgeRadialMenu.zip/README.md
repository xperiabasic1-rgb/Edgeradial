# Edge Radial Menu (Android, Kotlin)

Menu radial dari tepi layar: Screenshot, Rekam Layar, Mode Pesawat, Senter,
Control Center, Notifikasi, Bluetooth, Jangan Ganggu.

## Build lewat GitHub
1. Buat repo baru di GitHub, upload semua isi folder ini (pastikan folder `.github` ikut).
2. Buka tab **Actions** > workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Setelah hijau, buka run-nya, bagian **Artifacts**, unduh `EdgeRadialMenu-debug-apk`, ekstrak, install `app-debug.apk`.

## Setup di HP
1. Buka app > izinkan tampil di atas aplikasi lain.
2. Aktifkan layanan Aksesibilitas "Edge Radial Menu" (untuk Screenshot, Control Center, Notifikasi).
3. Beri akses Jangan Ganggu.
4. Tekan "Aktifkan menu tepi".

Edit daftar menu: app/src/main/java/com/example/edgemenu/Actions.kt
