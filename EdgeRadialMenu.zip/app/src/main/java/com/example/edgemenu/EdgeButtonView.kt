package com.example.edgemenu

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/** Tombol setengah lingkaran di tepi kiri layar. Tap = buka menu, geser vertikal = pindahkan. */
class EdgeButtonView(
    context: Context,
    private val currentY: () -> Int,
    private val onMoveY: (Int) -> Unit,
    private val onTap: () -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E61F2238") }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = d * 1.2f; color = Color.argb(60, 255, 255, 255)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private var downRawY = 0f
    private var startY = 0
    private var moved = false

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(-w, 0f, w, h)
        canvas.drawArc(rect, -90f, 180f, true, fill)
        canvas.drawArc(rect, -90f, 180f, false, edge)
        canvas.drawCircle(w * 0.45f, h / 2f, d * 5f, dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downRawY = e.rawY; startY = currentY(); moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.rawY - downRawY
                if (!moved && abs(dy) > slop) moved = true
                if (moved) onMoveY(startY + dy.toInt())
            }
            MotionEvent.ACTION_UP -> if (!moved) onTap()
        }
        return true
    }
}
