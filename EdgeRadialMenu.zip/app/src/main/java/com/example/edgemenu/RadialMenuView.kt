package com.example.edgemenu

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Panel setengah lingkaran dari tepi kiri.
 * - Putar (geser jari mengelilingi pusat) untuk mencari menu lain.
 * - Tap ikon untuk menjalankan aksi. Tap di luar panel / di pusat untuk menutup.
 */
class RadialMenuView(
    context: Context,
    private val items: List<MenuItem>,
    private val centerYHint: Float,
    private val onClosed: () -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val outerR = dp(150f)
    private val innerR = dp(58f)
    private val slot = 45f            // derajat per slot
    private val visibleSlots = 4
    private val maxScroll: Float get() = max(0, items.size - visibleSlots).toFloat()

    private var scroll = 0f
    private var openP = 0f
    private var pressed = -1
    private var closing = false
    private var snapAnim: ValueAnimator? = null

    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var fromCenter = false
    private var lastAngle = 0f

    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2262A40")
        setShadowLayer(dp(16f), 0f, dp(4f), Color.argb(110, 0, 0, 0))
    }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F51A1D2E") }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(1.2f); color = Color.argb(50, 255, 255, 255)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(210, 140, 108, 240) }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2222640") }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = dp(15f) }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200
            interpolator = DecelerateInterpolator()
            addUpdateListener { openP = it.animatedValue as Float; invalidate() }
        }.start()
    }

    private fun cy(): Float {
        val lo = outerR + dp(12f)
        val hi = height - outerR - dp(12f)
        return if (height <= 0) centerYHint else if (lo > hi) height / 2f else centerYHint.coerceIn(lo, hi)
    }

    private fun angleOf(i: Int) = (i - scroll) * slot - 67.5f
    private fun angleDeg(x: Float, dy: Float) = Math.toDegrees(atan2(dy, x).toDouble()).toFloat()

    override fun onDraw(canvas: Canvas) {
        val cy = cy()
        canvas.drawColor(Color.argb((100 * openP).toInt(), 0, 0, 0))

        canvas.save()
        canvas.scale(openP, openP, 0f, cy)
        canvas.drawCircle(0f, cy, outerR, panel)
        canvas.drawCircle(0f, cy, outerR, stroke)
        canvas.drawCircle(0f, cy, innerR, inner)
        canvas.drawCircle(0f, cy, innerR, stroke)

        if (pressed in items.indices) {
            val a = angleOf(pressed)
            val p = Path()
            p.arcTo(RectF(-outerR, cy - outerR, outerR, cy + outerR), a - slot / 2, slot)
            p.arcTo(RectF(-innerR, cy - innerR, innerR, cy + innerR), a + slot / 2, -slot)
            p.close()
            canvas.drawPath(p, glow)
        }

        val mid = (innerR + outerR) / 2f
        val half = (dp(30f) / 2f).toInt()
        for (i in items.indices) {
            val a = angleOf(i)
            val al = ((105f - abs(a)) / 35f).coerceIn(0f, 1f)
            if (al <= 0f) continue
            val rad = Math.toRadians(a.toDouble())
            val x = (mid * cos(rad)).toFloat()
            val y = cy + (mid * sin(rad)).toFloat()
            val ic = items[i].icon
            ic.setBounds(-half, -half, half, half)
            ic.alpha = (255 * al * openP).roundToInt()
            canvas.save()
            canvas.translate(x, y)
            ic.draw(canvas)
            canvas.restore()
        }

        canvas.drawCircle(dp(22f), cy, dp(6f), dot)
        canvas.restore()

        if (pressed in items.indices) {
            val label = items[pressed].label
            val a = Math.toRadians(angleOf(pressed).toDouble())
            val y = cy + (mid * sin(a)).toFloat()
            val tw = text.measureText(label)
            val padX = dp(16f)
            val h = dp(40f)
            var left = outerR + dp(10f)
            if (left + tw + 2 * padX > width - dp(8f)) left = width - dp(8f) - tw - 2 * padX
            val r = RectF(left, y - h / 2, left + tw + 2 * padX, y + h / 2)
            canvas.drawRoundRect(r, dp(14f), dp(14f), bubble)
            canvas.drawText(label, r.left + padX, y + text.textSize * 0.35f, text)
        }
    }

    private fun itemAt(x: Float, y: Float, cy: Float): Int {
        val dist = hypot(x, y - cy)
        if (dist < innerR || dist > outerR) return -1
        val ang = angleDeg(x, y - cy)
        for (i in items.indices) {
            val a = angleOf(i)
            if (abs(a) <= 90f && abs(a - ang) <= slot / 2) return i
        }
        return -1
    }

    private fun snap() {
        val target = scroll.roundToInt().toFloat().coerceIn(0f, maxScroll)
        snapAnim?.cancel()
        snapAnim = ValueAnimator.ofFloat(scroll, target).apply {
            duration = 160
            addUpdateListener { scroll = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun close() {
        if (closing) return
        closing = true
        ValueAnimator.ofFloat(openP, 0f).apply {
            duration = 140
            addUpdateListener { openP = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { onClosed() }
            })
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (closing) return true
        val cy = cy()
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snapAnim?.cancel()
                val dist = hypot(x, y - cy)
                if (dist > outerR + dp(6f)) { close(); return true }
                downX = x; downY = y; moved = false
                fromCenter = dist < innerR
                lastAngle = angleDeg(x, y - cy)
                pressed = if (fromCenter) -1 else itemAt(x, y, cy)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(x - downX, y - downY) > slop) { moved = true; pressed = -1 }
                if (moved && !fromCenter) {
                    val a = angleDeg(x, y - cy)
                    var delta = a - lastAngle
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f
                    scroll = (scroll - delta / slot).coerceIn(0f, maxScroll)
                    lastAngle = a
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    if (fromCenter) {
                        close()
                    } else if (pressed in items.indices) {
                        val item = items[pressed]
                        pressed = -1
                        close()
                        item.action()
                    }
                } else if (!fromCenter) snap()
                pressed = -1
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; snap(); invalidate() }
        }
        return true
    }
}
