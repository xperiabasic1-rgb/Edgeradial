package com.example.edgemenu

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Hanya dipakai untuk GLOBAL_ACTION_LOCK_SCREEN dan GLOBAL_ACTION_RECENTS. */
class ActionAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: ActionAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
