package com.example.edgemenu

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor("#1F2238"))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        col.addView(tv("Edge Radial Menu", 26f, true))
        col.addView(tv("Tombol setengah lingkaran di tepi layar. Ketuk untuk membuka panel, putar untuk mencari menu, ketuk ikon untuk menjalankan aksi. Geser tombol naik/turun untuk memindahkannya.", 15f))

        status = tv("", 14f)
        col.addView(status)

        col.addView(btn("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2. Aktifkan Aksesibilitas (Screenshot, Control Center, Notifikasi)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("3. Beri akses Jangan Ganggu") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        toggle = btn("") { toggleService() }
        col.addView(toggle)

        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        status.text = (if (ok) "✔ Izin overlay: aktif" else "✘ Izin overlay: belum diberikan") +
            "\n" + (if (OverlayService.running) "✔ Menu: berjalan" else "• Menu: mati")
        toggle.text = if (OverlayService.running) "Matikan menu tepi" else "4. Aktifkan menu tepi"
    }

    private fun toggleService() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(i)
            OverlayService.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) { refresh(); return }
            startForegroundService(i)
            OverlayService.running = true
        }
        refresh()
    }
}
