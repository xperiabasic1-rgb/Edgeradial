package com.example.edgemenu

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast

/**
 * Daftar menu radial. Mau tambah / ubah / urutkan menu? Edit fungsi build() di bawah.
 */
object Actions {

    private var torchOn = false

    fun build(ctx: Context): List<MenuItem> {
        fun vec(res: Int, tint: Int = Color.WHITE): Drawable =
            ctx.getDrawable(res)!!.mutate().also { it.setTint(tint) }

        val recording = ScreenRecordService.recording
        return listOf(
            MenuItem("Screenshot", vec(R.drawable.ic_screenshot)) { screenshot(ctx) },
            MenuItem(
                if (recording) "Stop Rekam" else "Rekam Layar",
                if (recording) vec(R.drawable.ic_stop, Color.parseColor("#FF5252")) else vec(R.drawable.ic_record)
            ) { toggleRecord(ctx) },
            MenuItem("Mode Pesawat", vec(R.drawable.ic_airplane)) { openSettings(ctx, Settings.ACTION_AIRPLANE_MODE_SETTINGS) },
            MenuItem("Senter", vec(R.drawable.ic_flashlight)) { toggleTorch(ctx) },
            MenuItem("Control Center", vec(R.drawable.ic_tune)) { globalAction(ctx, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) },
            MenuItem("Notifikasi", vec(R.drawable.ic_bell)) { globalAction(ctx, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) },
            MenuItem("Bluetooth", vec(R.drawable.ic_bluetooth)) { openSettings(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) },
            MenuItem("Jangan Ganggu", vec(R.drawable.ic_dnd)) { toggleDnd(ctx) }
        )
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    private fun openSettings(ctx: Context, action: String) {
        try {
            ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(ctx, "Tidak bisa membuka pengaturan")
        }
    }

    private fun screenshot(ctx: Context) {
        val svc = needAccessibility(ctx) ?: return
        // tunggu menu radial hilang dulu supaya tidak ikut ter-screenshot
        Handler(Looper.getMainLooper()).postDelayed({
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }, 500)
    }

    private fun toggleRecord(ctx: Context) {
        if (ScreenRecordService.recording) {
            ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP))
        } else {
            ctx.startActivity(Intent(ctx, ScreenRecordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleTorch(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) { toast(ctx, "Perangkat tanpa flash"); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            toast(ctx, if (torchOn) "Senter menyala" else "Senter mati")
        } catch (e: Exception) {
            toast(ctx, "Senter gagal: ${e.message}")
        }
    }

    private fun toggleDnd(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast(ctx, "Beri akses Jangan Ganggu dulu")
            openSettings(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        val on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        toast(ctx, if (on) "Jangan Ganggu: mati" else "Jangan Ganggu: aktif")
    }

    private fun needAccessibility(ctx: Context): ActionAccessibilityService? {
        val svc = ActionAccessibilityService.instance
        if (svc == null) {
            toast(ctx, "Aktifkan layanan Aksesibilitas dulu")
            openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        return svc
    }

    private fun globalAction(ctx: Context, action: Int) {
        needAccessibility(ctx)?.performGlobalAction(action)
    }
}
