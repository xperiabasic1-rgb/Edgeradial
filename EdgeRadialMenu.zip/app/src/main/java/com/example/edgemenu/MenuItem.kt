package com.example.edgemenu

import android.graphics.drawable.Drawable

data class MenuItem(
    val label: String,
    val icon: Drawable,
    val action: () -> Unit
)
