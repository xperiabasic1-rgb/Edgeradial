package com.example.edgemenu

import android.graphics.drawable.Drawable

/**
 * keepOpen = true  -> panel tetap terbuka setelah item ditekan (untuk toggle seperti senter).
 * isActive         -> kalau mengembalikan true, ikon diberi lingkaran terang (status "menyala").
 */
data class MenuItem(
    val label: String,
    val icon: Drawable,
    val keepOpen: Boolean = false,
    val isActive: (() -> Boolean)? = null,
    val action: () -> Unit
)
