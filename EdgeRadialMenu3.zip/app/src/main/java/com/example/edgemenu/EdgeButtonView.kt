package com.example.edgemenu

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/** Tombol kecil setengah lingkaran bergaya kaca transparan. Tap = buka menu, geser vertikal = pindahkan. */
class EdgeButtonView(
    context: Context,
    private val currentY: () -> Int,
    private val onMoveY: (Int) -> Unit,
    private val onTap: () -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(85, 18, 18, 22) }
    private val glass = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 1.2f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 255, 255, 255) }

    private var downRawY = 0f
    private var startY = 0
    private var moved = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        glass.shader = RadialGradient(
            0f, h / 2f, w.toFloat().coerceAtLeast(1f),
            intArrayOf(Color.argb(12, 255, 255, 255), Color.argb(34, 255, 255, 255), Color.argb(90, 255, 255, 255)),
            floatArrayOf(0.2f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(210, 255, 255, 255), Color.argb(50, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(-w, 0f, w, h)
        canvas.drawArc(rect, -90f, 180f, true, base)
        canvas.drawArc(rect, -90f, 180f, true, glass)
        canvas.drawArc(rect, -90f, 180f, false, rim)
        canvas.drawCircle(w * 0.42f, h / 2f, d * 3.5f, dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downRawY = e.rawY; startY = currentY(); moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.rawY - downRawY
                if (!moved && abs(dy) > slop) moved = true
                if (moved) onMoveY(startY + dy.toInt())
            }
            MotionEvent.ACTION_UP -> if (!moved) onTap()
        }
        return true
    }
}
