package com.example.edgemenu

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Dipakai untuk: Screenshot, Quick Settings, Notifikasi,
 * dan menekan tile "Rekam Layar" bawaan HP di panel Quick Settings.
 */
class ActionAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: ActionAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Cari elemen dengan teks/deskripsi cocok di semua jendela, lalu klik. */
    fun clickByText(pattern: Regex): Boolean {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        try { windows?.forEach { w -> w.root?.let { roots.add(it) } } } catch (_: Exception) {}
        rootInActiveWindow?.let { roots.add(it) }
        for (r in roots) {
            val node = find(r, pattern) ?: continue
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun find(node: AccessibilityNodeInfo, pattern: Regex): AccessibilityNodeInfo? {
        val t = node.text?.toString() ?: ""
        val cd = node.contentDescription?.toString() ?: ""
        if (pattern.containsMatchIn(t) || pattern.containsMatchIn(cd)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            find(child, pattern)?.let { return it }
        }
        return null
    }
}
