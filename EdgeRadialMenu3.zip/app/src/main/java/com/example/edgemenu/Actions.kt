package com.example.edgemenu

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast

/**
 * Daftar menu radial. Mau tambah / ubah / urutkan menu? Edit fungsi build() di bawah.
 */
object Actions {

    private var torchOn = false
    private var torchId: String? = null
    private var torchCb = false

    // App perekam layar bawaan beberapa merek (kalau terpasang, ini dipakai dulu)
    private val RECORDER_PKGS = listOf(
        "com.miui.screenrecorder",
        "com.coloros.screenrecorder",
        "com.oplus.screenrecorder",
        "com.huawei.screenrecorder"
    )
    private val RECORD_TILE = Regex(
        "\\b(screen ?record(er|ing)?|record screen|perekam layar|rekam layar|rekaman layar)",
        RegexOption.IGNORE_CASE
    )

    fun build(ctx: Context): List<MenuItem> {
        ensureTorchTracking(ctx)
        fun vec(res: Int, tint: Int = Color.WHITE): Drawable =
            ctx.getDrawable(res)!!.mutate().also { it.setTint(tint) }

        val recording = ScreenRecordService.recording
        return listOf(
            MenuItem("Screenshot", vec(R.drawable.ic_screenshot)) { screenshot(ctx) },
            MenuItem(
                if (recording) "Stop Rekam" else "Rekam Layar",
                if (recording) vec(R.drawable.ic_stop, Color.parseColor("#FF5252")) else vec(R.drawable.ic_record)
            ) { toggleRecord(ctx) },
            MenuItem("Senter", vec(R.drawable.ic_flashlight), keepOpen = true, isActive = { torchOn }) { toggleTorch(ctx) },
            MenuItem("Control Center", vec(R.drawable.ic_tune)) { globalAction(ctx, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) },
            MenuItem("Notifikasi", vec(R.drawable.ic_bell)) { globalAction(ctx, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) },
            MenuItem("Jangan Ganggu", vec(R.drawable.ic_dnd), keepOpen = true, isActive = { isDndOn(ctx) }) { toggleDnd(ctx) }
        )
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    private val main = Handler(Looper.getMainLooper())

    private fun openSettings(ctx: Context, action: String) {
        try {
            ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(ctx, "Tidak bisa membuka pengaturan")
        }
    }

    // ---------- Screenshot ----------
    private fun screenshot(ctx: Context) {
        val svc = needAccessibility(ctx) ?: return
        // tunggu panel menu hilang dulu supaya tidak ikut ter-screenshot
        main.postDelayed({ svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }, 500)
    }

    // ---------- Rekam layar: bawaan HP dulu, kalau tidak ada baru perekam app ini ----------
    private fun toggleRecord(ctx: Context) {
        if (ScreenRecordService.recording) {
            ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP))
            return
        }
        // 1) app perekam bawaan merek tertentu
        for (pkg in RECORDER_PKGS) {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: continue
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        // 2) tile "Rekam Layar" di Quick Settings bawaan
        val svc = ActionAccessibilityService.instance
        if (svc != null) {
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            tryTile(ctx, svc, 0)
        } else {
            ownRecorder(ctx)
        }
    }

    private fun tryTile(ctx: Context, svc: ActionAccessibilityService, attempt: Int) {
        main.postDelayed({
            if (svc.clickByText(RECORD_TILE)) return@postDelayed
            if (attempt < 5) {
                tryTile(ctx, svc, attempt + 1)
            } else {
                // HP tidak punya tile rekam layar -> tutup panel, pakai perekam app ini
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                main.postDelayed({ ownRecorder(ctx) }, 400)
            }
        }, if (attempt == 0) 700L else 400L)
    }

    private fun ownRecorder(ctx: Context) {
        ctx.startActivity(Intent(ctx, ScreenRecordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Senter ----------
    private fun ensureTorchTracking(ctx: Context) {
        if (torchCb) return
        try {
            val cm = ctx.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torchOn = enabled
                }
            }, main)
            torchCb = true
        } catch (_: Exception) {}
    }

    private fun toggleTorch(ctx: Context) {
        try {
            val id = torchId
            if (id == null) { toast(ctx, "Perangkat tanpa flash"); return }
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            toast(ctx, "Senter gagal: ${e.message}")
        }
    }

    // ---------- Jangan Ganggu ----------
    private fun isDndOn(ctx: Context): Boolean {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        return nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }

    private fun toggleDnd(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            toast(ctx, "Beri akses Jangan Ganggu dulu")
            openSettings(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        nm.setInterruptionFilter(
            if (isDndOn(ctx)) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
    }

    // ---------- Aksesibilitas ----------
    private fun needAccessibility(ctx: Context): ActionAccessibilityService? {
        val svc = ActionAccessibilityService.instance
        if (svc == null) {
            toast(ctx, "Aktifkan layanan Aksesibilitas dulu")
            openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        return svc
    }

    private fun globalAction(ctx: Context, action: Int) {
        needAccessibility(ctx)?.performGlobalAction(action)
    }
}
