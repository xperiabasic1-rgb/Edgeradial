package com.example.edgemenu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Merekam layar (tanpa suara) ke Movies/EdgeMenu. */
class ScreenRecordService : Service() {

    companion object {
        @Volatile var recording = false
        const val ACTION_STOP = "com.example.edgemenu.STOP_RECORD"
        private const val CHANNEL = "edge_record"
        private const val NOTIF_ID = 2
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecording()
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            startRecording(code, data)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal merekam: ${e.message}", Toast.LENGTH_LONG).show()
            stopRecording()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Rekam layar", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Merekam layar…")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stop), "Stop", stopPi
                ).build()
            )
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startRecording(code: Int, data: Intent) {
        val dm = resources.displayMetrics
        var w = dm.widthPixels
        var h = dm.heightPixels
        if (w > 1080) { h = h * 1080 / w; w = 1080 }
        w = w and 1.inv()
        h = h and 1.inv()

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME,
                "rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/EdgeMenu")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        pfd = contentResolver.openFileDescriptor(uri!!, "w")

        val rec = MediaRecorder(this)
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        rec.setVideoSize(w, h)
        rec.setVideoFrameRate(30)
        rec.setVideoEncodingBitRate(8_000_000)
        rec.setOutputFile(pfd!!.fileDescriptor)
        rec.prepare()
        recorder = rec

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopRecording(); stopSelf() }
        }, Handler(mainLooper))
        projection = proj

        display = proj.createVirtualDisplay(
            "edge_rec", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
        )
        rec.start()
        recording = true
    }

    private fun stopRecording() {
        if (stopped) return
        stopped = true
        val wasRecording = recording
        recording = false
        runCatching { if (wasRecording) recorder?.stop() }
        runCatching { recorder?.release() }
        runCatching { display?.release() }
        runCatching { projection?.stop() }
        runCatching { pfd?.close() }
        uri?.let {
            runCatching {
                contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            }
            if (wasRecording) Toast.makeText(this, "Rekaman disimpan di Movies/EdgeMenu", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }
}
