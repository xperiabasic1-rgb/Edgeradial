package com.example.edgemenu

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private class Row(val check: TextView, val btn: Button)

    private lateinit var rowOverlay: Row
    private lateinit var rowA11y: Row
    private lateinit var rowDnd: Row
    private lateinit var rowNotif: Row
    private lateinit var summary: TextView
    private lateinit var toggle: Button

    private val green = Color.parseColor("#4ADE80")
    private val gray = Color.parseColor("#6B7280")
    private val d get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(Color.parseColor("#111111"))
        background = rounded(Color.parseColor("#E5E7EB"), 18)
        minHeight = 0; minimumHeight = 0
        setPadding(dp(16), dp(8), dp(16), dp(8))
        setOnClickListener { onClick() }
    }

    private fun addRow(parent: LinearLayout, title: String, desc: String, onClick: () -> Unit): Row {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.parseColor("#1C1D22"), 16)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val check = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(dp(6), 0, dp(10), 0)
        }
        mid.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        })
        mid.addView(TextView(this).apply {
            text = desc; textSize = 12f; setTextColor(Color.parseColor("#9CA3AF"))
        })
        val btn = smallBtn("Atur", onClick)
        card.addView(check); card.addView(mid); card.addView(btn)
        parent.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })
        return Row(check, btn)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(52), dp(20), dp(28))
        }
        col.addView(TextView(this).apply {
            text = "Edge Radial Menu"; textSize = 26f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Selesaikan semua izin di bawah sampai bertanda ✔, lalu aktifkan menu."
            textSize = 14f; setTextColor(Color.parseColor("#9CA3AF")); setPadding(0, dp(6), 0, dp(8))
        })
        summary = TextView(this).apply { textSize = 13f; setTextColor(green) }
        col.addView(summary)

        rowOverlay = addRow(col, "Tampil di atas aplikasi lain", "Wajib. Untuk menampilkan tombol tepi.") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        rowA11y = addRow(col, "Layanan Aksesibilitas", "Untuk Screenshot, Control Center, Notifikasi, dan Rekam Layar bawaan HP.") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        rowDnd = addRow(col, "Akses Jangan Ganggu", "Untuk mengaktifkan/mematikan mode Jangan Ganggu.") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        rowNotif = addRow(col, "Notifikasi", "Untuk notifikasi layanan & rekam layar.") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        toggle = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.parseColor("#111111"))
            setOnClickListener { toggleService() }
        }
        col.addView(toggle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(22) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0E0F12"))
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(this, ActionAccessibilityService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    }

    private fun setRow(row: Row, ok: Boolean) {
        row.check.text = if (ok) "✔" else "○"
        row.check.setTextColor(if (ok) green else gray)
        row.btn.text = if (ok) "Diatur" else "Atur"
        row.btn.alpha = if (ok) 0.6f else 1f
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val a11y = isAccessibilityOn()
        val dnd = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

        setRow(rowOverlay, overlay)
        setRow(rowA11y, a11y)
        setRow(rowDnd, dnd)
        setRow(rowNotif, notif)

        val done = listOf(overlay, a11y, dnd, notif).count { it }
        summary.text = if (done == 4) "✔ Semua izin sudah lengkap" else "$done dari 4 izin selesai"
        summary.setTextColor(if (done == 4) green else Color.parseColor("#FBBF24"))

        val running = OverlayService.running
        toggle.text = if (running) "Matikan menu tepi" else "Aktifkan menu tepi"
        toggle.isEnabled = overlay || running
        toggle.alpha = if (toggle.isEnabled) 1f else 0.4f
        toggle.background = rounded(if (running) Color.parseColor("#F87171") else green, 26)
    }

    private fun toggleService() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(i)
            OverlayService.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) { refresh(); return }
            startForegroundService(i)
            OverlayService.running = true
        }
        refresh()
    }
}
