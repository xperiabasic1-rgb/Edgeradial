package com.example.edgemenu

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Panel setengah lingkaran bergaya kaca transparan (tanpa menggelapkan layar).
 * - Putar: geser jari mengelilingi pusat. Menu berputar tanpa ujung + ada momentum (fling).
 * - Tap ikon: jalankan aksi. Tap di luar panel / di pusat: tutup.
 */
class RadialMenuView(
    context: Context,
    private val items: List<MenuItem>,
    private val centerYHint: Float,
    private val onClosed: () -> Unit
) : View(context) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val outerR = dp(140f)
    private val innerR = dp(54f)
    private val slot = 45f              // derajat per slot
    private val gain = 1.3f             // putaran sedikit lebih cepat dari jari
    private val n: Int get() = items.size
    private val wrap: Boolean get() = n >= 5      // berputar tanpa ujung kalau cukup banyak menu
    private val maxScroll: Float get() = max(0, n - 4).toFloat()

    private var scroll = 0f
    private var openP = 0f
    private var pressed = -1
    private var closing = false
    private var anim: ValueAnimator? = null
    private var lastTick = 0

    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var fromCenter = false
    private var lastAngle = 0f
    private var lastMoveTime = 0L
    private var vel = 0f                // derajat per ms

    // ---- cat kaca ----
    private val baseFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(95, 18, 18, 22) }
    private val innerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(110, 10, 10, 14) }
    private val glass = Paint(Paint.ANTI_ALIAS_FLAG)
    private val innerGlass = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1.4f) }
    private val innerRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1.2f) }
    private val glowFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 255, 255, 255) }
    private val glowStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(1.2f); color = Color.argb(150, 255, 255, 255)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 255, 255, 255) }
    private val activeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(95, 255, 255, 255) }
    private val activeStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(1.4f); color = Color.argb(190, 255, 255, 255)
    }
    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(175, 22, 22, 28) }
    private val bubbleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(1f); color = Color.argb(70, 255, 255, 255)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = dp(15f) }

    private var shaderCy = Float.NaN
    private fun ensureShaders(cy: Float) {
        if (shaderCy == cy) return
        shaderCy = cy
        glass.shader = RadialGradient(
            0f, cy, outerR,
            intArrayOf(Color.argb(10, 255, 255, 255), Color.argb(28, 255, 255, 255), Color.argb(85, 255, 255, 255)),
            floatArrayOf(0.35f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        innerGlass.shader = RadialGradient(
            0f, cy, innerR,
            intArrayOf(Color.argb(8, 255, 255, 255), Color.argb(50, 255, 255, 255)),
            floatArrayOf(0.4f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, cy - outerR, 0f, cy + outerR,
            Color.argb(215, 255, 255, 255), Color.argb(50, 255, 255, 255), Shader.TileMode.CLAMP
        )
        innerRim.shader = LinearGradient(
            0f, cy - innerR, 0f, cy + innerR,
            Color.argb(190, 255, 255, 255), Color.argb(40, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 200
            interpolator = DecelerateInterpolator()
            addUpdateListener { openP = it.animatedValue as Float; invalidate() }
        }.start()
    }

    private val loc = IntArray(2)

    /** centerYHint = Y tombol di LAYAR; dikonversi ke koordinat view ini (menghindari selisih status bar / poni). */
    private fun cy(): Float {
        getLocationOnScreen(loc)
        val hint = centerYHint - loc[1]
        val lo = outerR + dp(12f)
        val hi = height - outerR - dp(12f)
        return if (height <= 0) hint else if (lo > hi) height / 2f else hint.coerceIn(lo, hi)
    }

    private fun angleOf(i: Int): Float {
        var a = (i - scroll) * slot - 67.5f
        if (wrap) {
            val p = n * slot
            a = ((a + p / 2) % p + p) % p - p / 2
        }
        return a
    }

    private fun angleDeg(x: Float, dy: Float) = Math.toDegrees(atan2(dy, x).toDouble()).toFloat()

    private fun setScroll(v: Float) {
        scroll = if (wrap) v else v.coerceIn(0f, maxScroll)
        val t = scroll.roundToInt()
        if (t != lastTick) {
            lastTick = t
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cy = cy()
        ensureShaders(cy)

        canvas.save()
        canvas.scale(openP, openP, 0f, cy)

        canvas.drawCircle(0f, cy, outerR, baseFill)
        canvas.drawCircle(0f, cy, outerR, glass)
        canvas.drawCircle(0f, cy, outerR, rim)
        canvas.drawCircle(0f, cy, innerR, innerFill)
        canvas.drawCircle(0f, cy, innerR, innerGlass)
        canvas.drawCircle(0f, cy, innerR, innerRim)

        if (pressed in items.indices) {
            val a = angleOf(pressed)
            val p = Path()
            p.arcTo(RectF(-outerR, cy - outerR, outerR, cy + outerR), a - slot / 2, slot)
            p.arcTo(RectF(-innerR, cy - innerR, innerR, cy + innerR), a + slot / 2, -slot)
            p.close()
            canvas.drawPath(p, glowFill)
            canvas.drawPath(p, glowStroke)
        }

        val mid = (innerR + outerR) / 2f
        val half = (dp(28f) / 2f).toInt()
        for (i in items.indices) {
            val a = angleOf(i)
            val al = ((105f - abs(a)) / 35f).coerceIn(0f, 1f)
            if (al <= 0f) continue
            val rad = Math.toRadians(a.toDouble())
            val x = (mid * cos(rad)).toFloat()
            val y = cy + (mid * sin(rad)).toFloat()
            val ic = items[i].icon
            ic.setBounds(-half, -half, half, half)
            ic.alpha = (255 * al).roundToInt()
            canvas.save()
            canvas.translate(x, y)
            if (i == pressed) canvas.scale(1.15f, 1.15f)
            if (items[i].isActive?.invoke() == true) {
                canvas.drawCircle(0f, 0f, dp(21f), activeFill)
                canvas.drawCircle(0f, 0f, dp(21f), activeStroke)
            }
            ic.draw(canvas)
            canvas.restore()
        }

        canvas.drawCircle(dp(20f), cy, dp(5f), dot)
        canvas.restore()

        if (pressed in items.indices) {
            val label = items[pressed].label
            val a = Math.toRadians(angleOf(pressed).toDouble())
            val y = cy + (mid * sin(a)).toFloat()
            val tw = text.measureText(label)
            val padX = dp(16f)
            val h = dp(38f)
            var left = outerR + dp(10f)
            if (left + tw + 2 * padX > width - dp(8f)) left = width - dp(8f) - tw - 2 * padX
            val r = RectF(left, y - h / 2, left + tw + 2 * padX, y + h / 2)
            canvas.drawRoundRect(r, dp(16f), dp(16f), bubble)
            canvas.drawRoundRect(r, dp(16f), dp(16f), bubbleStroke)
            canvas.drawText(label, r.left + padX, y + text.textSize * 0.35f, text)
        }
    }

    private fun itemAt(x: Float, y: Float, cy: Float): Int {
        val dist = hypot(x, y - cy)
        if (dist < innerR || dist > outerR) return -1
        val ang = angleDeg(x, y - cy)
        for (i in items.indices) {
            val a = angleOf(i)
            if (abs(a) <= 90f && abs(a - ang) <= slot / 2) return i
        }
        return -1
    }

    private fun animateTo(target: Float, duration: Long, interp: TimeInterpolator) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(scroll, target).apply {
            this.duration = duration
            interpolator = interp
            addUpdateListener { setScroll(it.animatedValue as Float); invalidate() }
            start()
        }
    }

    private fun snap() {
        animateTo(scroll.roundToInt().toFloat().let { if (wrap) it else it.coerceIn(0f, maxScroll) },
            160, DecelerateInterpolator())
    }

    private fun fling() {
        val travelSlots = -(vel * gain * 320f) / slot
        var target = (scroll + travelSlots).roundToInt().toFloat()
        if (!wrap) target = target.coerceIn(0f, maxScroll)
        val dist = abs(target - scroll)
        val dur = min(1100f, 350f + dist * 70f).toLong()
        animateTo(target, dur, DecelerateInterpolator(1.8f))
    }

    fun close() {
        if (closing) return
        closing = true
        anim?.cancel()
        ValueAnimator.ofFloat(openP, 0f).apply {
            duration = 140
            addUpdateListener { openP = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { onClosed() }
            })
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (closing) return true
        val cy = cy()
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                val dist = hypot(x, y - cy)
                if (dist > outerR + dp(6f)) { close(); return true }
                downX = x; downY = y; moved = false
                fromCenter = dist < innerR
                lastAngle = angleDeg(x, y - cy)
                lastMoveTime = e.eventTime
                vel = 0f
                lastTick = scroll.roundToInt()
                pressed = if (fromCenter) -1 else itemAt(x, y, cy)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(x - downX, y - downY) > slop) { moved = true; pressed = -1 }
                if (moved && !fromCenter) {
                    val a = angleDeg(x, y - cy)
                    var delta = a - lastAngle
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f
                    val dt = e.eventTime - lastMoveTime
                    if (dt > 0) vel = 0.6f * vel + 0.4f * (delta / dt)
                    lastMoveTime = e.eventTime
                    setScroll(scroll - delta * gain / slot)
                    lastAngle = a
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    if (fromCenter) {
                        close()
                    } else if (pressed in items.indices) {
                        val item = items[pressed]
                        pressed = -1
                        if (item.keepOpen) {
                            // panel tetap terbuka, hanya perbarui status ikon
                            item.action()
                            postInvalidateDelayed(150)
                            postInvalidateDelayed(500)
                        } else {
                            close()
                            item.action()
                        }
                    }
                } else if (!fromCenter) {
                    if (e.eventTime - lastMoveTime > 90) vel = 0f
                    if (abs(vel) > 0.12f) fling() else snap()
                }
                pressed = -1
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; snap(); invalidate() }
        }
        return true
    }
}
