package com.example.edgemenu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "edge_menu"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var button: EdgeButtonView? = null
    private var menu: RadialMenuView? = null
    private lateinit var btnParams: WindowManager.LayoutParams

    private val dm get() = resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        menu?.let { runCatching { wm.removeView(it) } }
        button?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Edge Menu", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Edge Radial Menu aktif")
            .setContentText("Ketuk untuk membuka pengaturan")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun addButton() {
        val prefs = getSharedPreferences("edge", MODE_PRIVATE)
        val h = dp(44)
        btnParams = WindowManager.LayoutParams(
            dp(22), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            x = 0
            y = prefs.getInt("y", dm.heightPixels / 2 - h / 2)
        }
        val v = EdgeButtonView(
            this,
            currentY = { btnParams.y },
            onMoveY = { ny ->
                btnParams.y = ny.coerceIn(0, dm.heightPixels - btnParams.height)
                button?.let { wm.updateViewLayout(it, btnParams) }
                prefs.edit().putInt("y", btnParams.y).apply()
            },
            onTap = { showMenu() }
        )
        button = v
        wm.addView(v, btnParams)
    }

    private fun showMenu() {
        if (menu != null) return
        val items = Actions.build(this)
        // posisi tengah tombol yang sebenarnya di layar
        val loc = IntArray(2)
        val b = button
        b?.getLocationOnScreen(loc)
        val cy = if (b != null && b.height > 0) loc[1] + b.height / 2f else btnParams.y + btnParams.height / 2f
        val mv = RadialMenuView(this, items, cy) { hideMenu() }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        menu = mv
        wm.addView(mv, p)
        button?.visibility = View.INVISIBLE
    }

    private fun hideMenu() {
        menu?.let { runCatching { wm.removeView(it) } }
        menu = null
        button?.visibility = View.VISIBLE
    }
}
